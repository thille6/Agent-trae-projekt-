1:"/_next/static/chunks/1tq6ppe__m8m-.js"
2:"LoadingBoundaryProvider"
3:I[39756,["$1"],"$2"]
4:"$Sreact.fragment"
5:I[39756,["$1"],"default"]
6:"/_next/static/chunks/19rmwar_rv5l2.js"
7:I[8821,["$1","$6"],"default"]
8:I[37457,["$1"],"default"]
:HL["/_next/static/chunks/0fupn5nk_8jwo.css","style"]
a:X
a:C
b:X
b:300
b:C
f:X
f:C
13:X
13:C
10:[["children",{"s":"__PAGE__","h":49314,"d":{"r":"$L11","p":"$@12","v":"$13","s":"$b"}}]]
c:[["children",{"s":"/_not-found","h":49250,"d":{"r":["$","$4","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","template":"$Ld"}]]}],"p":"$@e","v":"$f","s":"$b"},"c":"$Q10"}]]
18:X
18:C
1b:X
1b:C
0:{"t":{"t":{"s":"","h":49238,"d":{"r":["$","$L3",null,{"loading":[["$","main","l",{"className":"min-h-screen bg-background","children":["$","div",null,{"className":"mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8","children":[["$","section",null,{"className":"rounded-[32px] border border-border bg-surface px-6 py-8 shadow-card","children":[["$","div",null,{"className":"h-5 w-52 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-12 w-full max-w-3xl rounded-2xl bg-panel"}],["$","div",null,{"className":"mt-4 h-7 w-full max-w-2xl rounded-2xl bg-panel"}]]}],["$","section",null,{"className":"mt-6 grid gap-4","children":[["$","div","0",{"className":"rounded-[28px] border border-border bg-surface p-5 shadow-card","children":[["$","div",null,{"className":"h-6 w-44 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-20 rounded-3xl bg-panel"}],["$","div",null,{"className":"mt-5 grid gap-4 xl:grid-cols-3","children":[["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}]]}]]}],["$","div","1",{"className":"rounded-[28px] border border-border bg-surface p-5 shadow-card","children":[["$","div",null,{"className":"h-6 w-44 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-20 rounded-3xl bg-panel"}],["$","div",null,{"className":"mt-5 grid gap-4 xl:grid-cols-3","children":[["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}]]}]]}],["$","div","2",{"className":"rounded-[28px] border border-border bg-surface p-5 shadow-card","children":[["$","div",null,{"className":"h-6 w-44 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-20 rounded-3xl bg-panel"}],["$","div",null,{"className":"mt-5 grid gap-4 xl:grid-cols-3","children":[["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}]]}]]}],["$","div","3",{"className":"rounded-[28px] border border-border bg-surface p-5 shadow-card","children":[["$","div",null,{"className":"h-6 w-44 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-20 rounded-3xl bg-panel"}],["$","div",null,{"className":"mt-5 grid gap-4 xl:grid-cols-3","children":[["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}]]}]]}]]}]]}]}],[],null],"children":["$","$4","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0fupn5nk_8jwo.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/1tq6ppe__m8m-.js","async":true}]],["$","html",null,{"lang":"en","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L5",null,{"parallelRouterKey":"children","error":"$7","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/19rmwar_rv5l2.js","async":true}]],"template":["$","$L8",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]}]}]]}]}],"p":"$@9","v":"$a","s":"$b"},"c":"$Qc"},"h":{"r":["$","$4","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],"$L14","$L15","$L16"]}],"p":"$@17","v":"$18","s":"$b"}},"a":"$@19","u":"$@1a","b":"FMqT7kCIfdsCL97Eul_mH","r":"$1b"}
1c:I[97367,["$1"],"OutletBoundary"]
1d:"$Sreact.suspense"
1f:"ViewportBoundary"
20:I[97367,["$1"],"$1f"]
21:"MetadataBoundary"
22:I[97367,["$1"],"$21"]
23:I[27201,["$1"],"IconMark"]
d:["$","$L8",null,{}]
11:["$","$4","c",{"children":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":"$0:t:t:d:r:props:children:props:children:1:props:children:props:children:props:notFound:0:1:props:style","children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":"$0:t:t:d:r:props:children:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:1:props:style","children":404}],["$","div",null,{"style":"$0:t:t:d:r:props:children:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:style","children":["$","h2",null,{"style":"$0:t:t:d:r:props:children:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:children:props:style","children":"This page could not be found."}]}]]}]}]],null,["$","$L1c",null,{"children":["$","$1d",null,{"name":"Next.MetadataOutlet","children":"$@1e"}]}]]}]
14:["$","$L20",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}]
15:["$","$L22",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$1d",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Apex Football Tips"}],["$","meta","1",{"name":"description","content":"Real-fixture football tip board with 1X2 probabilities, Over/Under 2.5, BTTS, confidence bands, and live table-driven modeling."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L23","3",{}]]}]}],null]}]
16:["$","meta",null,{"name":"next-size-adjust","content":""}]
1a:false
1e:null
19:null
e:"$undefined"
9:"$undefined"
17:"$undefined"
12:"$undefined"
