:HL["/_next/static/chunks/0fupn5nk_8jwo.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":49314}]]
1:[["children",{"s":"design","h":49250,"c":"$Q2"}]]
0:{"b":"FMqT7kCIfdsCL97Eul_mH","t":{"t":{"s":"","h":49238,"c":"$Q1"}}}
