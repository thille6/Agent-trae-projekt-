1:"/_next/static/chunks/1tq6ppe__m8m-.js"
2:"LoadingBoundaryProvider"
3:I[39756,["$1"],"$2"]
4:"$Sreact.fragment"
5:I[39756,["$1"],"default"]
6:"/_next/static/chunks/19rmwar_rv5l2.js"
7:I[8821,["$1","$6"],"default"]
8:I[37457,["$1"],"default"]
12:I[68027,["$1"],"default",1]
:HL["/_next/static/chunks/0fupn5nk_8jwo.css","style"]
9:X
c:X
f:X
d:[["children",{"s":"__PAGE__","h":514,"d":{"r":"$Le","p":true,"v":"$f"}}]]
a:[["children",{"s":"/_not-found","h":514,"d":{"r":"$Lb","p":true,"v":"$c"},"c":"$Qd"}]]
11:X
14:X
15:X
0:{"P":null,"c":["","_not-found"],"q":"","i":false,"t":{"t":{"s":"","h":534,"d":{"r":["$","$L3",null,{"loading":[["$","main","l",{"className":"min-h-screen bg-background","children":["$","div",null,{"className":"mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8","children":[["$","section",null,{"className":"rounded-[32px] border border-border bg-surface px-6 py-8 shadow-card","children":[["$","div",null,{"className":"h-5 w-52 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-12 w-full max-w-3xl rounded-2xl bg-panel"}],["$","div",null,{"className":"mt-4 h-7 w-full max-w-2xl rounded-2xl bg-panel"}]]}],["$","section",null,{"className":"mt-6 grid gap-4","children":[["$","div","0",{"className":"rounded-[28px] border border-border bg-surface p-5 shadow-card","children":[["$","div",null,{"className":"h-6 w-44 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-20 rounded-3xl bg-panel"}],["$","div",null,{"className":"mt-5 grid gap-4 xl:grid-cols-3","children":[["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}]]}]]}],["$","div","1",{"className":"rounded-[28px] border border-border bg-surface p-5 shadow-card","children":[["$","div",null,{"className":"h-6 w-44 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-20 rounded-3xl bg-panel"}],["$","div",null,{"className":"mt-5 grid gap-4 xl:grid-cols-3","children":[["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}]]}]]}],["$","div","2",{"className":"rounded-[28px] border border-border bg-surface p-5 shadow-card","children":[["$","div",null,{"className":"h-6 w-44 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-20 rounded-3xl bg-panel"}],["$","div",null,{"className":"mt-5 grid gap-4 xl:grid-cols-3","children":[["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}]]}]]}],["$","div","3",{"className":"rounded-[28px] border border-border bg-surface p-5 shadow-card","children":[["$","div",null,{"className":"h-6 w-44 rounded-full bg-panel"}],["$","div",null,{"className":"mt-5 h-20 rounded-3xl bg-panel"}],["$","div",null,{"className":"mt-5 grid gap-4 xl:grid-cols-3","children":[["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}],["$","div",null,{"className":"h-28 rounded-3xl bg-panel"}]]}]]}]]}]]}]}],[],null],"children":["$","$4","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0fupn5nk_8jwo.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/1tq6ppe__m8m-.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L5",null,{"parallelRouterKey":"children","error":"$7","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/19rmwar_rv5l2.js","async":true,"nonce":"$undefined"}]],"template":["$","$L8",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}]}],"p":true,"v":"$9"},"c":"$Qa"},"h":{"r":"$L10","p":true,"v":"$11"}},"m":"$undefined","G":["$12",["$L13"]],"S":true,"r":"$14","s":"$15","a":"$@16","l":"$undefined","p":"$undefined","d":"$undefined","b":"FMqT7kCIfdsCL97Eul_mH","u":"$@17"}
18:I[97367,["$1"],"OutletBoundary"]
19:"$Sreact.suspense"
1b:"ViewportBoundary"
1c:I[97367,["$1"],"$1b"]
1e:"MetadataBoundary"
1f:I[97367,["$1"],"$1e"]
b:["$","$4","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L8",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
e:["$","$4","c",{"children":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":"$0:t:t:d:r:props:children:props:children:1:props:children:props:children:props:notFound:0:1:props:style","children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":"$0:t:t:d:r:props:children:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:1:props:style","children":404}],["$","div",null,{"style":"$0:t:t:d:r:props:children:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:style","children":["$","h2",null,{"style":"$0:t:t:d:r:props:children:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:children:props:style","children":"This page could not be found."}]}]]}]}]],null,["$","$L18",null,{"children":["$","$19",null,{"name":"Next.MetadataOutlet","children":"$@1a"}]}]]}]
10:["$","$4","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L1c",null,{"children":"$L1d"}],["$","$L1f",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$19",null,{"name":"Next.Metadata","children":"$L20"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
13:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0fupn5nk_8jwo.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
c:C
15:300
1d:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
21:I[27201,["$1"],"IconMark"]
1a:null
20:[["$","title","0",{"children":"Apex Football Tips"}],["$","meta","1",{"name":"description","content":"Real-fixture football tip board with 1X2 probabilities, Over/Under 2.5, BTTS, confidence bands, and live table-driven modeling."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L21","3",{}]]
15:C
11:C
14:C
f:C
9:C
17:false
16:null
